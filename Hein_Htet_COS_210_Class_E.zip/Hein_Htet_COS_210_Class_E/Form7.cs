﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            groupBox2.Hide();
            fillClassId();
            fillTrainerId();
            autoEnrollID();
        }
        private void autoEnrollID()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT MAX(Eid) FROM Enrollment";
                    object result = cmd.ExecuteScalar();

                    if (result == DBNull.Value || result == null || string.IsNullOrEmpty(result.ToString()))
                    {
                        txtEnroll.Text = "E001";
                    }
                    else
                    {
                        // Assumes Eid is in the format "E###"
                        string lastId = result.ToString();
                        int num = 1;
                        if (lastId.Length > 1 && int.TryParse(lastId.Substring(1), out int parsed))
                        {
                            num = parsed + 1;
                        }
                        txtEnroll.Text = "E" + num.ToString("D3");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void fillClassId()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select Cid from Dance_Classes";
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                 cboClass.Items.Add("Select");
                 cboClass.DataSource = dt;
                 cboClass.DisplayMember = "Cid";

               /* int i = 0;
                while (i < dt.Rows.Count)
                {
                    cboClass.Items.Add(dt.Rows[i]["Cid"].ToString());
                    i++;
                }*/

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void fillTrainerId()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select Tid from Instructor";
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                cboTrainer.Items.Add("Select");
                cboTrainer.DataSource = dt;
                cboTrainer.DisplayMember = "Tid";

                /* int i = 0;
                 while (i < dt.Rows.Count)
                 {
                     cboClass.Items.Add(dt.Rows[i]["Tid"].ToString());
                     i++;
                 }

                 con.Close();*/
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            var F4 = new Form4();
            F4.Show();
            this.Hide();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            groupBox2.Show();
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            try
            {
                
                    if (!int.TryParse(txtAge.Text, out int age) || age <=10 || age >=50)
                    {
                        MessageBox.Show("Sorry,Age must be BETWEEN 10 and 50 old");
                        return;
                    }
                SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "Insert into Enrollment(Eid,Cid,Tid,Name,Age,Height,Weight) values ('" + txtEnroll.Text + "','" + cboClass.Text + "','" + cboTrainer.Text + "','" + txtName.Text + "','" + txtAge.Text + "','" + txtHeight.Text + "','" + txtWeight.Text + "')";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Enrollment Success");
                conn.Close();
                var F4 = new Form4();
                F4.Show();
                this.Hide();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
