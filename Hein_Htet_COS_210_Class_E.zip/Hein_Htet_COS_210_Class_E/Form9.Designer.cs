﻿namespace Hein_Htet_COS_210_Class_E
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form9));
            this.btnEM = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnTM = new System.Windows.Forms.Button();
            this.btnCM = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEM
            // 
            this.btnEM.BackColor = System.Drawing.Color.Transparent;
            this.btnEM.Font = new System.Drawing.Font("Wide Latin", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEM.ForeColor = System.Drawing.Color.DimGray;
            this.btnEM.Location = new System.Drawing.Point(12, 142);
            this.btnEM.Name = "btnEM";
            this.btnEM.Size = new System.Drawing.Size(281, 56);
            this.btnEM.TabIndex = 7;
            this.btnEM.Text = "Enrollment Management";
            this.btnEM.UseVisualStyleBackColor = false;
            this.btnEM.Click += new System.EventHandler(this.btnEM_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Transparent;
            this.btnExit.Font = new System.Drawing.Font("Wide Latin", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.DimGray;
            this.btnExit.Location = new System.Drawing.Point(595, 382);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(193, 56);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnTM
            // 
            this.btnTM.BackColor = System.Drawing.Color.Transparent;
            this.btnTM.Font = new System.Drawing.Font("Wide Latin", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTM.ForeColor = System.Drawing.Color.DimGray;
            this.btnTM.Location = new System.Drawing.Point(12, 256);
            this.btnTM.Name = "btnTM";
            this.btnTM.Size = new System.Drawing.Size(274, 56);
            this.btnTM.TabIndex = 5;
            this.btnTM.Text = "Instructor Management";
            this.btnTM.UseVisualStyleBackColor = false;
            this.btnTM.Click += new System.EventHandler(this.btnTM_Click);
            // 
            // btnCM
            // 
            this.btnCM.BackColor = System.Drawing.Color.Transparent;
            this.btnCM.Font = new System.Drawing.Font("Wide Latin", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCM.ForeColor = System.Drawing.Color.DimGray;
            this.btnCM.Location = new System.Drawing.Point(12, 36);
            this.btnCM.Name = "btnCM";
            this.btnCM.Size = new System.Drawing.Size(281, 56);
            this.btnCM.TabIndex = 4;
            this.btnCM.Text = "Class Management";
            this.btnCM.UseVisualStyleBackColor = false;
            this.btnCM.Click += new System.EventHandler(this.btnCM_Click);
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEM);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnTM);
            this.Controls.Add(this.btnCM);
            this.Name = "Form9";
            this.Text = "Form9";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEM;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnTM;
        private System.Windows.Forms.Button btnCM;
    }
}