﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string st = "admin";
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
               // cmd.CommandText = "SELECT * FROM UserAdmin WHERE username = '" + textBox1.Text + "' AND password = '" + textBox2.Text + "' AND position = '" + st + "'";
                cmd.CommandText = "Select * from UserAdmin where username= '" 
                    + textBox1.Text + "' and password = '" + textBox2.Text + "' and position ='" + st + "'";
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Please enter both Username and Password!");
                    return;
                }
                else if (dt.Rows.Count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    var F9 = new Form9();
                    F9.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password!");
                }

                MessageBox.Show("Only Admin can Login!!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void cboPW_CheckedChanged(object sender, EventArgs e)
        {
            if (cboPW.Checked)
            {
                textBox1.PasswordChar = '\0'; // Show password
            }
            else
            {
                textBox2.PasswordChar = '*'; // Hide password
            }
        }

        private void lblForgot_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var F13 = new Form13();
            this.Hide();
            F13.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
