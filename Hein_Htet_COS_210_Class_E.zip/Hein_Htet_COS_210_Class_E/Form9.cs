﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void btnCM_Click(object sender, EventArgs e)
        {
            var F10 = new Form10();
            F10.Show();
            this.Hide();
        }

        private void btnEM_Click(object sender, EventArgs e)
        {
            var F11 = new Form12();
            F11.Show();
            this.Hide();
        }

        private void btnTM_Click(object sender, EventArgs e)
        {
            var F12 = new Form11();
            F12.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                MessageBox.Show("You choose 'Yes'.");
                System.Windows.Forms.Application.Exit();
            }
            else
            {
                MessageBox.Show("You choose 'No'.");
            }
        }
    }
}
