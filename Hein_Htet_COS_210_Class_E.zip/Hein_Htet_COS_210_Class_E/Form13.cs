﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox1.PasswordChar = '\0'; // Show password
            }
            else
            {
                textBox1.PasswordChar = '*'; // Hide password
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            string email = textBox2.Text.Trim();
            string newPassword = textBox1.Text;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(newPassword))
            {
                MessageBox.Show("Please enter both email and new password.");
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    con.Open();
                    // Check if email exists
                    SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM UserAdmin WHERE Email = @Email", con);
                    checkCmd.Parameters.AddWithValue("@Email", email);
                    int exists = (int)checkCmd.ExecuteScalar();

                    if (exists == 1)
                    {
                        // Update password
                        SqlCommand updateCmd = new SqlCommand("UPDATE UserAdmin SET Password = @Password WHERE Email = @Email", con);
                        updateCmd.Parameters.AddWithValue("@Password", newPassword);
                        updateCmd.Parameters.AddWithValue("@Email", email);
                        updateCmd.ExecuteNonQuery();
                        MessageBox.Show("Password updated successfully!");
                        showUserAdminData(email);
                    }
                    else
                    {
                        MessageBox.Show("Email not found. Please enter a valid email.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void showUserAdminData(string email)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT Email, Password FROM UserAdmin WHERE Email = @Email";
                    cmd.Parameters.AddWithValue("@Email", email);
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var F2 = new Form2();
            F2.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var F8 = new Form8();
            F8.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
