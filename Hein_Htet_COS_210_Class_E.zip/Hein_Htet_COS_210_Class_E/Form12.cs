﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var F9 = new Form9();
            F9.Show();
            this.Hide();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            showEnrollData();
        }
     

        private void showEnrollData()
        {
            try
            {
                
                using (SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT * FROM Enrollment"; 
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt; 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells[0].Value.ToString(); // Eid
                textBox2.Text = row.Cells[1].Value.ToString(); // Cid
                textBox3.Text = row.Cells[2].Value.ToString(); // Tid
                textBox4.Text = row.Cells[3].Value.ToString(); // Name
                textBox5.Text = row.Cells[4].Value.ToString(); // Age
                textBox6.Text = row.Cells[5].Value.ToString(); // Height
                textBox7.Text = row.Cells[6].Value.ToString(); // Weight
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
        }

       private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                cn.Open();
                SqlCommand cd = cn.CreateCommand();
                cd.CommandType = CommandType.Text;
                cd.CommandText = "insert into Enrollment (Eid,Cid,Tid,Name,Age,Height,Weight) values ('" + textBox1.Text + "','" + textBox2.Text + "','"+ textBox3.Text + "','" + textBox4.Text + "','"+ textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "')";
                cd.ExecuteNonQuery();
                MessageBox.Show("Enrollment Added Successfully!");
                cn.Close();
                showEnrollData(); 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                    if (!int.TryParse(textBox5.Text, out int age) || age <= 10 || age >= 50)
                    {
                        MessageBox.Show("Sorry,Age must be BETWEEN 10 and 50 old");
                        return;
                    }
                SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                cn.Open();
                SqlCommand cd = cn.CreateCommand();
                cd.CommandType = CommandType.Text;
                cd.CommandText = "UPDATE Enrollment SET " +"Cid='" + textBox2.Text + "', " + "Tid='" + textBox3.Text + "', " +"Name='" + textBox4.Text + "', " + "Age='" + textBox5.Text + "', " + "Height='" + textBox6.Text + "', " + "Weight='" + textBox7.Text + "' " +"WHERE Eid='" + textBox1.Text + "'";
                cd.ExecuteNonQuery();
                MessageBox.Show("Enrollment Updated Successfully!");
                cn.Close();
                showEnrollData(); // Refresh the DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
        
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please select an enrollment to delete.");
                return;
            }
            else
            {
                try
                {
                    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "select * from Enrollment where Eid='" + textBox1.Text + "'";
                    SqlDataAdapter adp = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    if (dt.Rows.Count == 1)
                    {
                        cmd.CommandText = "delete from Enrollment where Eid='" + textBox1.Text + "'";
                        cmd.ExecuteNonQuery();
                        con.Close();
                        MessageBox.Show("Enrollment Deleted Successfully");
                        showEnrollData();
                        // Optionally clear the textboxes
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        textBox7.Text = "";
                    }
                    else
                    {
                        con.Close();
                        MessageBox.Show("Enrollment not found. Please check the Enrollment ID.");
                        textBox1.Text = "";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter Enrollment ID (Eid) to search.");
                return;
            }
            else
            {
                try
                {
                    SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                    cn.Open();
                    SqlCommand cd = cn.CreateCommand();
                    cd.CommandType = CommandType.Text;
                    cd.CommandText = "select * from Enrollment where Eid='" + textBox1.Text + "'";
                    SqlDataAdapter adp = new SqlDataAdapter(cd);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    cn.Close();

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                        MessageBox.Show("Enrollment found.");
                    }
                    else
                    {
                        MessageBox.Show("Enrollment not found. Please check the Enrollment ID.");
                        textBox1.Text = "";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            showEnrollData();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
        }
    }
    
    
    
}
