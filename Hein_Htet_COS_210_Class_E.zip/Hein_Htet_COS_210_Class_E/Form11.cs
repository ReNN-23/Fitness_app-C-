﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            showInstructor();
        }
        private void showInstructor()
        {
            try
            {
                SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                cn.Open();
                SqlCommand cd = cn.CreateCommand();
                cd.CommandType = CommandType.Text;
                cd.CommandText = "select * from Instructor";
                cd.ExecuteNonQuery();
                SqlDataAdapter dp = new SqlDataAdapter(cd);
                DataTable dt = new DataTable();
                dp.Fill(dt);
                dataGridView1.DataSource = dt;
                cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            string st = "";
            if (radioButton1.Checked == true)
            {
                st = radioButton1.Text;
            }
            else
            {
                st = radioButton2.Text;
            }

            try
            {
                SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                cn.Open();
                SqlCommand cd = cn.CreateCommand();
                cd.CommandType = CommandType.Text;
                cd.CommandText = "insert into Instructor (Tid,Name,Age,Experience,Specialization,Gender) values ('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "','" + st + "')";
                cd.ExecuteNonQuery();
                MessageBox.Show("Instructor Added Successfully!");
                cn.Close();
                showInstructor();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUPDATE_Click(object sender, EventArgs e)
        {
            string st = "";
            if (radioButton1.Checked == true)
            {
                st = radioButton1.Text;
            }
            else
            {
                st = radioButton2.Text;
            }
            try
            {
                SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                cn.Open();
                SqlCommand cd = cn.CreateCommand();
                cd.CommandType = CommandType.Text;
                cd.CommandText = "UPDATE Instructor SET Tid='" + textBox1.Text +
                 "', Name='" + textBox2.Text +
                 "', Age='" + textBox3.Text +
                 "', Experience='" + textBox4.Text +
                 "', Specialization='" + comboBox1.Text +
                 "', Gender='" + st +
                 "' WHERE Tid='" + textBox1.Text + "'";
                cd.ExecuteNonQuery();
                MessageBox.Show("Instructor Updated Successfully!");

                showInstructor();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow i = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = i.Cells[0].Value.ToString();
                textBox2.Text = i.Cells[1].Value.ToString();
                textBox3.Text = i.Cells[2].Value.ToString();
                textBox4.Text = i.Cells[3].Value.ToString();
                comboBox1.Text = i.Cells[4].Value.ToString();
                string gender = i.Cells[5].Value.ToString().Trim();
                if (gender == "Male")
                {
                    radioButton1.Checked = true;
                }
                else
                {
                    radioButton2.Checked = true;
                }

            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
         
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter Instructor ID (Tid) to search.");
                return;
            }

            try
            {
                using (SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    cn.Open();
                    SqlCommand cd = cn.CreateCommand();
                    cd.CommandType = CommandType.Text;
                    cd.CommandText = "SELECT * FROM Instructor WHERE Tid = @Tid";
                    cd.Parameters.AddWithValue("@Tid", textBox1.Text);

                    SqlDataAdapter dp = new SqlDataAdapter(cd);
                    DataTable dt = new DataTable();
                    dp.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        dataGridView1.DataSource = dt;
                        MessageBox.Show("Instructor found.");
                    }
                    else
                    {
                        MessageBox.Show("Instructor not found.");
                        dataGridView1.DataSource = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var F9 = new Form9();
            F9.Show();
            this.Hide();
        }

        private void btnRef_Click(object sender, EventArgs e)
        {
            showInstructor();

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
           
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please select an instructor to delete.");
                return;
            }
            else
            {
                try
                {
                    SqlConnection cn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                    cn.Open();
                    SqlCommand cd = cn.CreateCommand();
                    cd.CommandType = CommandType.Text;
                    cd.CommandText = "select * from Instructor where Tid='" + textBox1.Text + "'";
                    SqlDataAdapter adp = new SqlDataAdapter(cd);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    if (dt.Rows.Count == 1)
                    {
                        cd.CommandText = "delete from Instructor where Tid='" + textBox1.Text + "'";
                        cd.ExecuteNonQuery();
                        cn.Close();
                        MessageBox.Show("Instructor Deleted Successfully");
                        showInstructor();
                        // Optionally clear the textboxes
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        comboBox1.Text = "";
                        radioButton1.Checked = false;
                        radioButton2.Checked = false;
                    }
                    else
                    {
                        cn.Close();
                        MessageBox.Show("Instructor not found. Please check the Instructor ID.");
                        textBox1.Text = "";
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
    
}
