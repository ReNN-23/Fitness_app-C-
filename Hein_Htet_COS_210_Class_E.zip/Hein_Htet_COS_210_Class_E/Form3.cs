﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hein_Htet_COS_210_Class_E
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into UserAdmin(ID,Username,Password,Email,Position) values ('" + txtID.Text + "','" + txtName.Text + "','" + txtPassword.Text + "','" + txtEmail.Text + "','" + lblUser.Text + "')";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Registration Successful!");
                var F4 = new Form4();
                F4.Show();
                this.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            autoID();
        }
        private void autoID()
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus ROG\Documents\DanceClub.mdf"";Integrated Security=True;Connect Timeout=30");

                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select max(ID) from UserAdmin";
                object obj = cmd.ExecuteScalar();
                if (obj != DBNull.Value)
                {
                    int id = Convert.ToInt32(obj) + 1;
                    txtID.Text = id.ToString();
                }
                else
                {
                    txtID.Text = "1"; // If no records exist, start with ID 1
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
